<?php

return [
    'authors'   =>  [
        'base_uri'  =>  env('AUTHORS_SERVICE_BASE_URL'),
        'secret'  =>  env('AUTHORS_SERVICE_SECRET'),
    ],

    'books'   =>  [
        'base_uri'  =>  env('BOOKS_SERVICE_BASE_URL'),
        'secret'  =>  env('BOOKS_SERVICE_SECRET'),
    ],

    'admins'   =>  [
        'base_uri'  =>  env('ADMINS_SERVICE_BASE_URL'),
        'secret'  =>  env('ADMINS_SERVICE_SECRET'),
    ],

    'barangs'   =>  [
        'base_uri'  =>  env('BARANGS_SERVICE_BASE_URL'),
        'secret'  =>  env('BARANGS_SERVICE_SECRET'),
    ],

    'transactions'   =>  [
        'base_uri'  =>  env('TRANSAKSI_SERVICE_BASE_URL'),
        'secret'  =>  env('TRANSAKSI_SERVICE_SECRET'),
    ],
];