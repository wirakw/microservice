<?php

namespace App\Http\Controllers\Barang;

use App\Http\Controllers\Controller;
use App\Services\BarangService;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;

class BarangController extends Controller
{
    use ApiResponser;

    /**
     * The service to consume the barang micro-service
     * @var BarangService
     */
    public $barangService;

    public function __construct(BarangService $barangService)
    {
        $this->barangService = $barangService;
    }


    /**
     * Get Barang data
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        return $this->successResponse($this->barangService->obtainProducts());
    }


    /**
     * Save an Barang data
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        return $this->successResponse($this->barangService->createProduct($request->all()));
    }


    /**
     * Show a single Barang details
     * @param $barang
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($barang)
    {
        return $this->successResponse($this->barangService->obtainProduct($barang));
    }


    /**
     * Update a single Barang data
     * @param Request $request
     * @param $barang
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $barang)
    {
        return $this->successResponse($this->barangService->editProduct($request->all(),$barang));
    }


    /**
     * Delete a single Barang details
     * @param $barang
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($barang)
    {
        return $this->successResponse($this->barangService->deleteProduct($barang));
    }

}
