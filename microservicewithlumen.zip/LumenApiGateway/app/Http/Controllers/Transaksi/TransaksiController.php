<?php

namespace App\Http\Controllers\Transaksi;


use App\Http\Controllers\Controller;
use App\Services\TransaksiService;
use App\Services\BarangService;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;

class TransaksiController extends Controller
{
    use ApiResponser;

    /**
     * The service to consume the books micro-service
     * @var TransaksiService
     */
    public $transaksiService;

        /**
     * The service to consume the books micro-service
     * @var BarangService
     */
    public $barangService;

    public function __construct(TransaksiService $transaksiService, BarangService $barangService)
    {
        $this->transaksiService = $transaksiService;
        $this->barangService = $barangService;
    }

    /**
     * Save an book data
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function order(Request $request)
    {
        $this->barangService->obtainProduct($request->barang_id);
        return $this->successResponse($this->transaksiService->orderBarang($request->all()));
    }
}
