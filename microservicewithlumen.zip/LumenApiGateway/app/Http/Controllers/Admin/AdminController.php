<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Services\AdminService;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    use ApiResponser;

    /**
     * The service to consume the books micro-service
     * @var AdminService
     */
    public $adminService;

    public function __construct(AdminService $adminService)
    {
        $this->adminService = $adminService;
    }

    /**
     * Save an book data
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(Request $request)
    {
        return $this->successResponse($this->adminService->register($request->all()));
    }

        /**
     * Save an book data
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        return $this->successResponse($this->adminService->login($request->all()));
    }
}
