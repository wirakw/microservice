<?php

namespace App\Services;

use App\Traits\ConsumeExternalService;

class AdminService
{
    use ConsumeExternalService;

    /**
     * The base uri to consume authors service
     * @var string
     */
    public $baseUri;

    /**
     * Authorization secret to pass to book api
     * @var string
     */
    public $secret;

    public function __construct()
    {
        $this->baseUri = config('services.admins.base_uri');
        $this->secret = config('services.admins.secret');
    }

    public function register($data)
    {
        return $this->performRequest('POST', '/register', $data);
    }

    public function login($data)
    {
        return $this->performRequest('POST', '/login', $data);
    }
}