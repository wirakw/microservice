<?php

namespace App\Services;

use App\Traits\ConsumeExternalService;

class BarangService
{
    use ConsumeExternalService;

    /**
     * The base uri to consume authors service
     * @var string
     */
    public $baseUri;

    /**
     * Authorization secret to pass to product api
     * @var string
     */
    public $secret;

    public function __construct()
    {
        $this->baseUri = config('services.barangs.base_uri');
        $this->secret = config('services.barangs.secret');
    }


    public function obtainProducts()
    {
        return $this->performRequest('GET', '/all/product');
    }

    public function createProduct($data)
    {
        return $this->performRequest('POST', '/product', $data);
    }

    public function obtainProduct($barang)
    {
        return $this->performRequest('GET', "/product/{$barang}");
    }

    public function editProduct($data, $barang)
    {
        return $this->performRequest('PUT', "/product/{$barang}", $data);
    }

    public function deleteProduct($barang)
    {
        return $this->performRequest('DELETE', "/product/{$barang}");
    }
}