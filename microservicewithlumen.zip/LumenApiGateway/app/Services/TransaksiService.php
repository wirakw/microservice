<?php

namespace App\Services;

use App\Traits\ConsumeExternalService;

class TransaksiService
{
    use ConsumeExternalService;

    /**
     * The base uri to consume authors service
     * @var string
     */
    public $baseUri;

    /**
     * Authorization secret to pass to book api
     * @var string
     */
    public $secret;

    public function __construct()
    {
        $this->baseUri = config('services.transactions.base_uri');
        $this->secret = config('services.transactions.secret');
    }

    public function orderBarang($data)
    {
        return $this->performRequest('POST', '/order', $data);
    }
}