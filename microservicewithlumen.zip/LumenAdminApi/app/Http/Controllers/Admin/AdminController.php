<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use Firebase\JWT\JWT;

class AdminController extends Controller
{
    use ApiResponser;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }
    /**
     * Create a new token.
     * 
     * @param  \App\Models\Admin   $admin
     * @return string
     */
    protected function jwt(Admin $admin) {
        $payload = [
            'iss' => "lumen-jwt", // Issuer of the token
            'sub' => $admin->username, // Subject of the token
            'iat' => time(), // Time when JWT was issued. 
            'exp' => time() + 60*60 // Expiration time
        ];
        
        // As you can see we are passing `JWT_SECRET` as the second parameter that will 
        // be used to decode the token in the future.
        return JWT::encode($payload, env('JWT_SECRET'));
    } 
    /**
     * Registration Admin
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(Request $request)
    {
        $rules = [
            'username' => 'required|unique:admins|max:255',
            'password' => 'required|min:6'
        ];
        $this->validate($request, $rules);
        $username = $request->input("username");
        $password = $request->input("password");
 
        $hashPwd = Hash::make($password);
 
        $data = [
            "username" => $username,
            "password" => $hashPwd
        ];
 
        $admin = Admin::create($data);

        return $this->successResponse($admin, Response::HTTP_CREATED);
    }
    
    /**
     * Login Admin
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        $rules = [
            'username' => 'required|max:255',
            'password' => 'required|min:6'
        ];
        $this->validate($request, $rules);
        $username = $request->input("username");
        $password = $request->input("password");
 
        $admin = Admin::where("username", $username)->first();

        if (!$admin) {
            return $this->errorResponse("aaaaaaaaaaa Failed wrong username or Password", Response::HTTP_UNAUTHORIZED);
        }
 
        if (Hash::check($password, $admin->password)) {
            $admin->token = $this->jwt($admin);
            return $this->successResponse($admin);
        } else {
            return $this->errorResponse("login Failed wrong username or Password", Response::HTTP_UNAUTHORIZED);
        }
    }
}
