# Microservices with Lumen
sebelumnya composer update dulu semua service

run author service = php -S localhost:8066 -t public

run book service = php -S localhost:8067 -t public

run admin service = php -S localhost:8070 -t public

run barang service = php -S localhost:8065 -t public

run transaksi service = php -S localhost:8064 -t public

run api gateway service = php -S localhost:8068 -t public