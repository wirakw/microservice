<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/
$router->get('/key', function() {
    return \Illuminate\Support\Str::random(32);
});
$router->post('/product', 'Product\ProductController@createProduct');
$router->put('/product/update', 'Product\ProductController@updateProductSpu');
$router->post('/product/delete', 'Product\ProductController@deleteProduct');
$router->post('/product/photo', 'Product\ProductController@postPhotoProduct');
$router->post('/product/varian', 'Product\ProductController@addProductVarian');
$router->put('/product/varian', 'Product\ProductController@updateVarianInfo');
$router->post('/product/varian/delete', 'Product\ProductController@deleteVarianInfo');
$router->post('/api/v1/dynamic', 'Product\ProductController@dynamicApi');
