<?php

return [
    'jdid' => [
        'base_uri' => env('JDID_SERVICE_BASE_URL'),
        'bigdata_uri' => env('JDID_UPLOAD_BASE_URL'),
        'appkey' => env('JDID_APPKEY'),
        'appSecret' => env('JDID_APPSECRET'),
        'accessToken' => env('JDID_AKSESTOKEN'),
        'version' => env('JDID_VERSION'),
        'format' => env('JDID_FORMAT'),
        'signMethod' => env('JDID_SIGNMETHOD'),
    ],

    'method' => [
        'createProduct' => env('JDID_CREATE_PRODUCT'),
        'updateProductSpu' => env('JDID_UPDATE_PRODUCT'),
        'deleteProduct' => env('JDID_DELETE_PRODUCT'),
        'addProductSku' => env('JDID_CREATE_VARIAN'),
        'updateProductSku' => env('JDID_UPDATE_VARIAN'),
        'deleteProductSku' => env('JDID_DELETE_VARIAN'),
        'spuMainPicture' => env('JDID_SPU_MAIN_PICTURE'),
        'spuDetailPicture' => env('JDID_SPU_DETAIL_PICTURE'),
        'skuMainPicture' => env('JDID_SKU_MAIN_PICTURE'),
        'skuDetailPicture' => env('JDID_SKU_DETAIL_PICTURE'),
        'categoryAuth' => env('JDID_CATEGORY_AUTH'),
    ],
];
