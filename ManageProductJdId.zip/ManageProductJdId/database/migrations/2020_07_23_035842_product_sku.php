<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ProductSku extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_sku', function (Blueprint $table) {
            $table->integer('skuId')->primary();            
            $table->integer('spuId')->unsigned()->nullable()->index();
            $table->integer('costPrice')->unsigned();
            $table->string('imgFlag');
            $table->string('saleAttrValueAlias');
            $table->integer('jdPrice')->unsigned();
            $table->integer('stock')->unsigned();
            $table->string('saleAttributeIds');
            $table->string('sellerSkuId');
            $table->string('skuName');
            $table->string('upc');
            $table->timestamps();
            // $table->foreign('spuId')->reference('spuId')->on('product_spu')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_sku');
    }
}
