<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ProductSpu extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_spu', function (Blueprint $table) {
            $table->integer('spuId')->primary();
            $table->string('appDescription');
            $table->integer('brandId')->unsigned();
            $table->integer('catId')->unsigned();
            $table->string('commomAttributeIds');
            $table->string('description');
            $table->boolean('isQuality');
            $table->boolean('isSequenceNumber');
            $table->string('keywords');
            $table->string('packageInfo');
            $table->string('productArea');
            $table->integer('qualityDays')->unsigned();
            $table->string('seqPrefixDigit');
            $table->integer('seqPrefixNumber')->unsigned();
            $table->integer('seqTotalNumber')->unsigned();
            $table->string('spuName');
            $table->string('subtitle');
            $table->string('subtitleHrefM');
            $table->integer('transportId')->unsigned();
            $table->integer('warrantyPeriod')->unsigned();
            $table->integer('whetherCod')->unsigned();
            $table->string('weight');
            $table->string('netWeight');
            $table->string('packHeight');
            $table->string('packLong');
            $table->string('packWide');
            $table->integer('piece')->unsigned();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_spu');
    }
}
