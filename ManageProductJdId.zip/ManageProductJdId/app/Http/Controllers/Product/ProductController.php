<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Models\ProductSkuModel;
use App\Models\ProductSpuModel;
use App\Services\ProductService;
use App\Traits\ApiResponser;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class ProductController extends Controller
{
    use ApiResponser;
    /**
     * The service to consume the barang micro-service
     * @var ProductService
     */
    public $productService;
    public $appKey;
    public $appSecret;
    public $accessToken;
    public function __construct(ProductService $productService)
    {
        $this->productService = $productService;
        $this->appKey = config('services.jdid.appkey');
        $this->appSecret = config('services.jdid.appSecret');
        $this->accessToken = config('services.jdid.accessToken');
    }
    public $version = "1.0";
    public $format = "json";
    public $signMethod = "md5";
    public $param_json;
    public $param_file;

    protected function generateSign($params)
    {
        ksort($params);
        $stringToBeSigned = $this->appSecret;
        foreach ($params as $k => $v) {
            if ("@" != substr($v, 0, 1)) {
                $stringToBeSigned .= "$k$v";
            }
        }
        unset($k, $v);
        $stringToBeSigned .= $this->appSecret;
        return strtoupper(md5($stringToBeSigned));
    }

    public function getStandardOffsetUTC($timezone)
    {
        if ($timezone == 'UTC') {
            return '+0000';
        } else {
            $timezone = new DateTimeZone($timezone);
            $transitions = array_slice($timezone->getTransitions(), -3, null, true);

            foreach (array_reverse($transitions, true) as $transition) {
                if ($transition['isdst'] == 1) {
                    continue;
                }
                return sprintf('%+03d%02u', $transition['offset'] / 3600, abs($transition['offset']) % 3600 / 60);
            }

            return false;
        }
    }

    public function getCurrentTimeFormatted()
    {
        return date("Y-m-d H:i:s") . '.000' . $this->getStandardOffsetUTC(date_default_timezone_get());
    }

    /**
     * Store a single product information
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function createProduct(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = config('services.method.createProduct');
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        //sign
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }
        //intodb
        $jdIDRestponse = [];
        $responseExternal = $this->productService->postToJdId($arr4Post);
        if (isset($responseExternal['openapi_data'])) {
            $jdIDRestponse = json_decode($responseExternal['openapi_data']);
            if ($jdIDRestponse->success == true) {
                $datadb = $request->all();
                $datadb["spuInfo"]["spuId"] = $jdIDRestponse->model->spuId;
                $dataSpu = $datadb["spuInfo"];
                $datadb["skuList"][0]["skuId"] = $jdIDRestponse->model->skuIdList[0]->skuId;
                $datadb["skuList"][0]["spuId"] = $jdIDRestponse->model->spuId;
                $dataSku = $datadb["skuList"][0];
                $spu = ProductSpuModel::create($dataSpu);
                $sku = ProductSkuModel::create($dataSku);
                return $this->successResponse($responseExternal['openapi_data'], Response::HTTP_CREATED);
            }
            return $this->errorResponse("Cant Create product", Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        return $this->errorResponse("Cant Create product", Response::HTTP_UNPROCESSABLE_ENTITY);
    }

    /**
     * Store a single product information
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function applyProductAudit(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = "epi.ware.openapi.WareOperation.doAudit";
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        //sign
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }
        //send HTTP request\
        return $this->successResponse($this->productService->postToJdId($arr4Post));
    }

    /**
     * Add Varian product/add sku product
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateProductSpu(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = "epi.ware.openapi.SpuApi.updateSpuInfo";
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }

        //intodb
        $jdIDRestponse = [];
        $responseExternal = $this->productService->postToJdId($arr4Post);
        if (isset($responseExternal['openapi_data'])) {
            $jdIDRestponse = json_decode($responseExternal['openapi_data']);
            if ($jdIDRestponse->success == true) {
                $datadb = $request->all();
                $dataSpu = $datadb["spuInfo"];
                $spuId = $datadb["spuInfo"]["spuId"];
                $spu = ProductSpuModel::findOrFail($spuId);
                $spu->update($dataSpu);
                return $this->successResponse($responseExternal['openapi_data']);
            }
            return $this->errorResponse("Cant update product", Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        return $this->errorResponse("Cant update product", Response::HTTP_UNPROCESSABLE_ENTITY);
    }

    /**
     * Add Varian product/add sku product
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteProduct(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = "epi.ware.openapi.WareOperation.delSpu";
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }

        //intodb
        $jdIDRestponse = [];
        $responseExternal = $this->productService->postToJdId($arr4Post);
        if (isset($responseExternal['openapi_data'])) {
            $jdIDRestponse = json_decode($responseExternal['openapi_data']);
            if ($jdIDRestponse->success == true) {
                $datadb = $request->all();
                $dataSpu = $datadb["spuIds"];
                $arr_spu = explode(",", $dataSpu);
                foreach ($arr_spu as $item) {
                    $spu = ProductSpuModel::findOrFail($item)->delete();
                }
                return $this->successResponse($responseExternal['openapi_data']);
            }
            return $this->errorResponse("fail delete product", Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        return $this->errorResponse("fail delete product", Response::HTTP_UNPROCESSABLE_ENTITY);
    }

    /**
     * Add Varian product/add sku product
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function addProductVarian(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = config('services.method.addProductSku');
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }
        //intodb
        $jdIDRestponse = [];
        $responseExternal = $this->productService->postToJdId($arr4Post);
        if (isset($responseExternal['openapi_data'])) {
            $jdIDRestponse = json_decode($responseExternal['openapi_data']);
            if (isset($jdIDRestponse->model[0])) {
                $datadb = $request->all();
                $datadb["skuList"][0]["skuId"] = $jdIDRestponse->model[0]->skuId;
                $datadb["skuList"][0]["spuId"] = $datadb["spuId"];
                $dataSku = $datadb["skuList"][0];
                $sku = ProductSkuModel::create($dataSku);
                return $this->successResponse($responseExternal['openapi_data'], Response::HTTP_CREATED);
            }
            return $this->errorResponse("fail add varian product", Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        return $this->errorResponse("fail add varian product", Response::HTTP_UNPROCESSABLE_ENTITY);
    }

    /**
     * Add Varian product/add sku product
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateVarianInfo(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = config('services.method.updateProductSku');
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }
        //intodb
        $jdIDRestponse = [];
        $responseExternal = $this->productService->postToJdId($arr4Post);
        if (isset($responseExternal['openapi_data'])) {
            $jdIDRestponse = json_decode($responseExternal['openapi_data']);
            if ($jdIDRestponse->success == true) {
                $datadb = $request->all();
                $dataSku = $datadb["skuInfo"];
                $skuId = $datadb["skuInfo"]["skuId"];
                $sku = ProductSkuModel::findOrFail($skuId);
                $sku->update($dataSku);
                return $this->successResponse($responseExternal['openapi_data']);
            }
            return $this->errorResponse("fail update varian product", Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        return $this->errorResponse("fail update varian product", Response::HTTP_UNPROCESSABLE_ENTITY);
    }

    /**
     * Add Varian product/add sku product
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteVarianInfo(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = config('services.method.deleteProductSku');
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }
        //intodb
        $jdIDRestponse = [];
        $responseExternal = $this->productService->postToJdId($arr4Post);
        if (isset($responseExternal['openapi_data'])) {
            $jdIDRestponse = json_decode($responseExternal['openapi_data']);
            if ($jdIDRestponse->success == true) {
                $datadb = $request->all();
                $dataSku = $datadb["skuIds"];
                $arr_sku = explode(",", $dataSku);
                foreach ($arr_sku as $item) {
                    $sku = ProductSkuModel::findOrFail($item)->delete();
                }
                return $this->successResponse($responseExternal['openapi_data']);
            }
            return $this->errorResponse("fail delete varian product", Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        return $this->errorResponse("fail delete varian product", Response::HTTP_UNPROCESSABLE_ENTITY);
    }

    /**
     * Add Varian product/add sku product
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function dynamicApi(Request $request)
    {
        //construct system parameters
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = app('request')->input('method');
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        //get business parameters
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        $sysParams["sign"] = $this->generateSign($sysParams);
        $arr4Post = array();
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            $arr4Post["$sysParamKey"] = $sysParamValue;
        }
        //send HTTP request
        return $this->successResponse($this->productService->postToJdId($arr4Post));
    }

    /**
     * Add Product Main Picture (sku photo)
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function postPhotoProduct(Request $request)
    {
        $sysParams["app_key"] = $this->appKey;
        $sysParams["v"] = $this->version;
        $sysParams["format"] = $this->format;
        $sysParams["sign_method"] = $this->signMethod;
        $sysParams["method"] = config('services.jdid.skuMainPicture');
        $sysParams["timestamp"] = $this->getCurrentTimeFormatted();
        $sysParams["access_token"] = $this->accessToken;
        $this->param_json = json_encode($request->all());
        $picName = $request->file('filePath')->getClientOriginalName();
        $picName = uniqid() . '_' . $picName;
        $destination_path = './upload/image/';
        $request->file('filePath')->move($destination_path, $picName);
        $this->param_file = $destination_path . '' . $picName;

        // $this->param_file = $request->input("filePath");
        if (null != $this->param_json && isset($this->param_json) && !empty($this->param_json)) {
            $sysParams["param_json"] = $this->param_json;
        } else {
            $sysParams["param_json"] = "{}";
        }
        if (null != $this->param_file && isset($this->param_file) && !empty($this->param_file)) {
            $sysParams["param_file_md5"] = strtoupper(md5_file($this->param_file));
        }
        $sysParams["sign"] = $this->generateSign($sysParams);
        unset($sysParams['param_file_md5']);
        $newArray = array();
        $arr4Post = array("name" => "param_file", "contents" => fopen($this->param_file, 'r'));
        array_push($newArray, $arr4Post);
        foreach ($sysParams as $sysParamKey => $sysParamValue) {
            // $arr4Post["$sysParamKey"] = $sysParamValue;
            $arr4Post["name"] = $sysParamKey;
            $arr4Post["contents"] = $sysParamValue;
            array_push($newArray, $arr4Post);
        }
        $client = new Client([
            'base_uri' => config('services.jdid.bigdata_uri'),
        ]);

        $response = $client->request('POST', config('services.jdid.bigdata_uri'), [
            'multipart' => $newArray,
        ]);
        return $this->successResponse($response->getBody()->getContents());
    }
}
