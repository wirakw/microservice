<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductSpuModel extends Model
{

    protected $table = 'product_spu';
    protected $primaryKey = 'spuId';
    public $incrementing = false;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'appDescription', 'brandId', 'spuId', 'catId', 'commomAttributeIds', 'description', 'isQuality', 'isSequenceNumber', 'keywords', 'packageInfo', 'productArea', 'qualityDays', 'seqPrefixDigit', 'seqPrefixNumber', 'seqTotalNumber', 'spuName', 'subtitle', 'subtitleHrefM', 'warrantyPeriod', 'transportId', 'whetherCod', 'weight', 'netWeight', 'packHeight', 'packLong', 'packWide', 'piece',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
}
