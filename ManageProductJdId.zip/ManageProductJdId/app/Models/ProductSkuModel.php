<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductSkuModel extends Model
{

    protected $table = 'product_sku';
    protected $primaryKey = 'skuId';
    public $incrementing = false;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'skuId', 'spuId', 'costPrice', 'imgFlag', 'saleAttrValueAlias', 'jdPrice', 'stock', 'saleAttributeIds', 'sellerSkuId', 'skuName', 'upc',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
}
